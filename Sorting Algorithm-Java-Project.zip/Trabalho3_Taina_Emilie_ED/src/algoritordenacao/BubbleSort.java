package algoritordenacao;

public class BubbleSort {
	
    public static void ordenar(int[] vetor) {
    	
        int tam = vetor.length;
        int comparacoes = 0;
        int trocas = 0;

        for (int i=0; i<tam-1; i++) {
        	
            for (int j = 0; j < tam-i-1; j++) {
                comparacoes++;
                
                if (vetor[j] > vetor[j+1]) {
                    int temp = vetor[j];
                    vetor[j] = vetor[j+1];
                    vetor[j+1] = temp;
                    trocas++;
                }
            }
        }

        System.out.println("\nTotal de comparações por Bubble Sort: " + comparacoes);
        System.out.println("Total de trocas de posições por Bubble Sort: " + trocas);
    }
}
