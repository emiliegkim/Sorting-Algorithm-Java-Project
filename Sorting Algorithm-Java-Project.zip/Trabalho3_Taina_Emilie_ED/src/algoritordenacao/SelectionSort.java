package algoritordenacao;

public class SelectionSort {
	
    public static void ordenar(int[] vetor) {
    	
        int tam = vetor.length;
        int comparacoes = 0;
        int trocas = 0;

        for (int i=0; i<tam-1; i++) {
        	
            int minIndex=i;
            for (int j=i+1; j<tam; j++) {
                comparacoes++;
                if (vetor[j]<vetor[minIndex]) {
                    minIndex=j;
                }
            }

            int temp = vetor[minIndex];
            vetor[minIndex] = vetor[i];
            vetor[i] = temp;
            trocas++;
        }

        System.out.println("\nTotal de comparações por Selection Sort: " + comparacoes);
        System.out.println("Total de trocas de posições por Selection Sort: " + trocas);
    }
}