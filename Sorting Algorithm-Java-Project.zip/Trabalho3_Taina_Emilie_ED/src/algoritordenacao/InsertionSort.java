package algoritordenacao;

public class InsertionSort {
	
    public static void ordenar(int[] vetor) {
    	
        int tam = vetor.length;
        int trocas = 0;
        int comparacoes = 0;

        for (int i=1; i<tam; i++) {
            int aux = vetor[i];
            int j = i-1;

            while (j>=0 && vetor[j] > aux) {
                vetor[j+1] = vetor[j];
                j--;
                trocas++;
                comparacoes++;
            }
            
            vetor[j+1] = aux;
            comparacoes++;
        }

        System.out.println("\nTotal de comparações por Insertion Sort: " + comparacoes);
        System.out.println("Total de trocas de posições por Insertion Sort: " + trocas);
    }
}