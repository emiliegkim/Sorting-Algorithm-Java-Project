package algoritordenacao;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    	
        Scanner sc = new Scanner(System.in);

        int[] vetor = new int[10];

        System.out.println("\nDigite 10 valores inteiros a serem ordenados: ");
        
        for (int i = 0; i < vetor.length; i++) {
            vetor[i] = sc.nextInt();
        }

        System.out.println("\nVetor original informado: ");
        imprimeVetor(vetor);

        //criar e retornar uma cópia do objeto
        int[] vBubbleSort = vetor.clone();
        int[] vSelectionSort = vetor.clone();
        int[] vInsertionSort = vetor.clone();

        BubbleSort.ordenar(vBubbleSort);
        SelectionSort.ordenar(vSelectionSort);
        InsertionSort.ordenar(vInsertionSort);
        
        System.out.println("\n________VETORES ORDENADOS:________");

        System.out.println("\nPor Bubble Sort:");
        imprimeVetor(vBubbleSort);

        System.out.println("\nPor Selection Sort:");
        imprimeVetor(vSelectionSort);

        System.out.println("\nPor Insertion Sort:");
        imprimeVetor(vInsertionSort);

    }

    public static void imprimeVetor(int[] vetor) {
    	
        for (int i = 0; i < vetor.length; i++) {
            System.out.print(vetor[i] + " ");
        }
        
        System.out.println();
    }
}
